# Programming
Yes, that's right.
Some attacks need to do things like [line jumps](Jumps.md), [math operations](Math.md), and those things that are programming-like. So there are functions to do all these things.

## Advanced structures examples ##
[Loops](Examples/Loops.csv)
[Labels](Examples/Labels.csv)

<!-- TODO: Add more advanced structures (if they're available) -->

